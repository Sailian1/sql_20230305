import datetime

teraz =  datetime.datetime.now()
print(teraz)
print(type(teraz))

print(teraz.strftime('date:%Y_%m_%d_time:%H_%S'))

