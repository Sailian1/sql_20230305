from selenium import webdriver
from selenium_OOP import LoginPage
from selenium1 import make_screenshot
import time


driver = webdriver.Chrome()
page = LoginPage(driver)
page.open()
time.sleep(0.5)
page.enter_username('standard_user')
time.sleep(0.5)
page.enter_password('secret_sauce')
time.sleep(0.5)
page.click_login()

try:
    assert driver.curent_url == 'https://www.saucedemo.com/inventory.html'
except AssertionError:
    print('Assercja nie przeszla')
else:
    print('Assercja przeszla')
finally:
    print('po asercji')
    driver.quit()

time.sleep(0.5)
make_screenshot(driver)
page.the_snapshot()
driver.quit()