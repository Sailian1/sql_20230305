def napisz_czesc():
    print('no siema')

if __name__ == '__main__':   #wykonaj tylko, kiedy plik bezpośrendio uruchomiony
    print('kod z pliku file1 ',__name__)

print('A to wykonaj zawsze, nawet, kiedy importujesz modul')