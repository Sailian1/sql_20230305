from funkcje2_kod import *

welcome_basic()
imie1 = 'Marysia'
lista_imion = ['Adam', 'Marek']

welcome_full('Waldemar', 38)
welcome_full(imie1, 12)
welcome_full(lista_imion[1], 94)

print(stan_zdrowia(90, 1.70))
print(stan_zdrowia(80))