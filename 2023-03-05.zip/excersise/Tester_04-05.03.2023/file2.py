from file1 import *
print('kod z pliku file2 ',__name__)

napisz_czesc()